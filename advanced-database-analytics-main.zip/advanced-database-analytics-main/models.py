# models.py

import sqlite3
from database import transaction, get_connection
from audit import log_action


def add_student(name, email, department, year):
    if not name.strip() or not department.strip():
        raise ValueError("Name and department are required.")

    if "@" not in email or "." not in email:
        raise ValueError("Enter a valid email.")

    with transaction() as conn:
        cursor = conn.execute("""
            INSERT INTO students(name, email, department, admission_year)
            VALUES (?, ?, ?, ?)
        """, (name.strip(), email.strip().lower(),
              department.strip(), int(year)))

        student_id = cursor.lastrowid
        log_action(conn, "INSERT", "students", f"ID={student_id}")

    print(f"Student created. ID: {student_id}")


def list_students():
    conn = get_connection()
    try:
        rows = conn.execute("""
            SELECT student_id, name, email, department, admission_year
            FROM students ORDER BY student_id
        """).fetchall()

        for row in rows:
            print(dict(row))
    finally:
        conn.close()


def add_course(code, name, credits=3):
    with transaction() as conn:
        cursor = conn.execute("""
            INSERT INTO courses(code, name, credits)
            VALUES (?, ?, ?)
        """, (code.upper().strip(), name.strip(), int(credits)))

        log_action(conn, "INSERT", "courses",
                   f"ID={cursor.lastrowid}")

    print("Course created successfully.")


def enroll_student(student_id, course_id):
    with transaction() as conn:
        cursor = conn.execute("""
            INSERT INTO enrollments(student_id, course_id)
            VALUES (?, ?)
        """, (int(student_id), int(course_id)))

        log_action(conn, "INSERT", "enrollments",
                   f"ID={cursor.lastrowid}")

    print("Student enrolled successfully.")


def record_score(enrollment_id, marks, exam_type="Final"):
    marks = float(marks)

    if not 0 <= marks <= 100:
        raise ValueError("Marks must be between 0 and 100.")

    with transaction() as conn:
        conn.execute("""
            INSERT INTO scores(enrollment_id, marks, exam_type)
            VALUES (?, ?, ?)
            ON CONFLICT(enrollment_id)
            DO UPDATE SET
                marks = excluded.marks,
                exam_type = excluded.exam_type
        """, (int(enrollment_id), marks, exam_type))

        log_action(conn, "UPSERT", "scores",
                   f"Enrollment={enrollment_id}, marks={marks}")

    print("Score saved.")


def update_email(student_id, email):
    if "@" not in email:
        raise ValueError("Enter a valid email.")

    with transaction() as conn:
        cursor = conn.execute("""
            UPDATE students SET email = ?
            WHERE student_id = ?
        """, (email.strip().lower(), int(student_id)))

        if cursor.rowcount == 0:
            raise ValueError("Student not found.")

        log_action(conn, "UPDATE", "students",
                   f"ID={student_id}, email updated")

    print("Email updated.")


def delete_student(student_id):
    with transaction() as conn:
        cursor = conn.execute("""
            DELETE FROM students WHERE student_id = ?
        """, (int(student_id),))

        if cursor.rowcount == 0:
            raise ValueError("Student not found.")

        log_action(conn, "DELETE", "students",
                   f"ID={student_id}")

    print("Student and related records deleted.")


def seed_demo_data():
    """Insert sample data once for testing."""

    with transaction() as conn:
        count = conn.execute(
            "SELECT COUNT(*) FROM students"
        ).fetchone()[0]

        if count:
            print("Students already exist; demo data skipped.")
            return

        students = [
            ("Ananya Rao", "ananya@example.com", "AIML", 2024),
            ("Rahul Kumar", "rahul@example.com", "CSE", 2024),
            ("Priya Sharma", "priya@example.com", "AIML", 2023),
            ("Arjun Reddy", "arjun@example.com", "ECE", 2024),
        ]

        conn.executemany("""
            INSERT INTO students(name, email, department, admission_year)
            VALUES (?, ?, ?, ?)
        """, students)

        courses = [
            ("AI101", "Artificial Intelligence", 4),
            ("DB201", "Database Management Systems", 4),
            ("ML301", "Machine Learning", 3),
        ]

        conn.executemany("""
            INSERT INTO courses(code, name, credits)
            VALUES (?, ?, ?)
        """, courses)

        student_ids = {
            row["email"]: row["student_id"]
            for row in conn.execute(
                "SELECT student_id, email FROM students"
            )
        }

        course_ids = {
            row["code"]: row["course_id"]
            for row in conn.execute(
                "SELECT course_id, code FROM courses"
            )
        }

        records = [
            ("ananya@example.com", "AI101", 92),
            ("ananya@example.com", "DB201", 88),
            ("ananya@example.com", "ML301", 95),
            ("rahul@example.com", "AI101", 76),
            ("rahul@example.com", "DB201", 81),
            ("priya@example.com", "AI101", 89),
            ("priya@example.com", "ML301", 94),
            ("arjun@example.com", "DB201", 67),
        ]

        for email, code, marks in records:
            cursor = conn.execute("""
                INSERT INTO enrollments(student_id, course_id)
                VALUES (?, ?)
            """, (student_ids[email], course_ids[code]))

            conn.execute("""
                INSERT INTO scores(enrollment_id, marks)
                VALUES (?, ?)
            """, (cursor.lastrowid, marks))

        log_action(conn, "SEED", "database", "Demo data inserted")

    print("Demo data inserted.")