# analytics.py

from database import get_connection


def department_report():
    query = """
        SELECT
            s.department,
            COUNT(DISTINCT s.student_id) AS students,
            COUNT(sc.score_id) AS recorded_scores,
            ROUND(AVG(sc.marks), 2) AS average_marks,
            MAX(sc.marks) AS highest_marks
        FROM students s
        LEFT JOIN enrollments e
            ON s.student_id = e.student_id
        LEFT JOIN scores sc
            ON e.enrollment_id = sc.enrollment_id
        GROUP BY s.department
        HAVING COUNT(DISTINCT s.student_id) > 0
        ORDER BY average_marks DESC
    """

    conn = get_connection()
    try:
        for row in conn.execute(query):
            print(dict(row))
    finally:
        conn.close()


def top_students(limit=5):
    query = """
        SELECT s.student_id, s.name, s.department,
               ROUND(AVG(sc.marks), 2) AS average_marks
        FROM students s
        JOIN enrollments e ON s.student_id = e.student_id
        JOIN scores sc ON e.enrollment_id = sc.enrollment_id
        GROUP BY s.student_id, s.name, s.department
        ORDER BY average_marks DESC
        LIMIT ?
    """

    conn = get_connection()
    try:
        for row in conn.execute(query, (int(limit),)):
            print(dict(row))
    finally:
        conn.close()


def above_average_students():
    query = """
        SELECT s.name, ROUND(AVG(sc.marks), 2) AS average_marks
        FROM students s
        JOIN enrollments e ON s.student_id = e.student_id
        JOIN scores sc ON e.enrollment_id = sc.enrollment_id
        GROUP BY s.student_id, s.name
        HAVING AVG(sc.marks) > (SELECT AVG(marks) FROM scores)
        ORDER BY average_marks DESC
    """

    conn = get_connection()
    try:
        for row in conn.execute(query):
            print(dict(row))
    finally:
        conn.close()


def course_report():
    query = """
        SELECT c.code, c.name,
               COUNT(DISTINCT e.student_id) AS enrolled_students,
               ROUND(AVG(sc.marks), 2) AS average_marks
        FROM courses c
        LEFT JOIN enrollments e ON c.course_id = e.course_id
        LEFT JOIN scores sc ON e.enrollment_id = sc.enrollment_id
        GROUP BY c.course_id, c.code, c.name
        ORDER BY average_marks DESC
    """

    conn = get_connection()
    try:
        for row in conn.execute(query):
            print(dict(row))
    finally:
        conn.close()


def student_transcript(student_id):
    query = """
        SELECT s.name, c.code, c.name AS course_name, sc.marks
        FROM students s
        JOIN enrollments e ON s.student_id = e.student_id
        JOIN courses c ON e.course_id = c.course_id
        LEFT JOIN scores sc ON e.enrollment_id = sc.enrollment_id
        WHERE s.student_id = ?
    """

    conn = get_connection()
    try:
        rows = conn.execute(query, (int(student_id),)).fetchall()

        for row in rows:
            print(dict(row))
    finally:
        conn.close()


def inspect_query_plan():
    conn = get_connection()
    try:
        rows = conn.execute("""
            EXPLAIN QUERY PLAN
            SELECT * FROM students WHERE department = ?
        """, ("AIML",)).fetchall()

        for row in rows:
            print(dict(row))
    finally:
        conn.close()