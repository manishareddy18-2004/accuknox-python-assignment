# database.py

import sqlite3
from pathlib import Path
from contextlib import contextmanager

DB_PATH = Path(__file__).resolve().parent / "academic_analytics.db"


def get_connection():
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


@contextmanager
def transaction():
    conn = get_connection()
    try:
        conn.execute("BEGIN")
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def initialize_database():
    conn = get_connection()
    try:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS students (
            student_id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            department TEXT NOT NULL,
            admission_year INTEGER NOT NULL
                CHECK(admission_year BETWEEN 2000 AND 2100)
        );

        CREATE TABLE IF NOT EXISTS courses (
            course_id INTEGER PRIMARY KEY AUTOINCREMENT,
            code TEXT NOT NULL UNIQUE,
            name TEXT NOT NULL,
            credits INTEGER NOT NULL CHECK(credits BETWEEN 1 AND 10)
        );

        CREATE TABLE IF NOT EXISTS enrollments (
            enrollment_id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL,
            course_id INTEGER NOT NULL,
            enrollment_date TEXT DEFAULT CURRENT_DATE,
            FOREIGN KEY(student_id) REFERENCES students(student_id)
                ON DELETE CASCADE,
            FOREIGN KEY(course_id) REFERENCES courses(course_id)
                ON DELETE CASCADE,
            UNIQUE(student_id, course_id)
        );

        CREATE TABLE IF NOT EXISTS scores (
            score_id INTEGER PRIMARY KEY AUTOINCREMENT,
            enrollment_id INTEGER NOT NULL UNIQUE,
            marks REAL NOT NULL CHECK(marks BETWEEN 0 AND 100),
            exam_type TEXT NOT NULL DEFAULT 'Final',
            FOREIGN KEY(enrollment_id)
                REFERENCES enrollments(enrollment_id)
                ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS external_contacts (
            external_id INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            email TEXT,
            company TEXT
        );

        CREATE TABLE IF NOT EXISTS audit_logs (
            log_id INTEGER PRIMARY KEY AUTOINCREMENT,
            action TEXT NOT NULL,
            entity TEXT NOT NULL,
            details TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );

        CREATE INDEX IF NOT EXISTS idx_student_department
            ON students(department);

        CREATE INDEX IF NOT EXISTS idx_enrollment_student
            ON enrollments(student_id);

        CREATE INDEX IF NOT EXISTS idx_enrollment_course
            ON enrollments(course_id);

        CREATE INDEX IF NOT EXISTS idx_score_marks
            ON scores(marks);
        """)
    finally:
        conn.close()