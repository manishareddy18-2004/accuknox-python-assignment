# Advanced Database Management and Analytics System

## Overview

A Python-based relational database application for managing
students, courses, enrollments, examination scores, and
external contact records.

## Technologies

- Python
- SQLite
- SQL
- REST APIs
- JSON
- CSV
- unittest

## Features

- Relational database design
- Primary keys and foreign-key constraints
- CRUD operations
- Transaction management
- SQL JOINs and subqueries
- GROUP BY and aggregate functions
- Database indexing
- REST API data ingestion
- CSV import and export
- Audit logging
- Automated tests

## Project Structure

- main.py: Application entry point
- database.py: Schema and database connections
- models.py: Database operations
- analytics.py: SQL analytics and reports
- api_service.py: REST API integration
- csv_handler.py: CSV processing
- audit.py: Database activity logs
- tests.py: Automated tests

## Requirements

Python 3.10 or later.

No external Python packages are required.

## Run the application

```bash
python3 main.py