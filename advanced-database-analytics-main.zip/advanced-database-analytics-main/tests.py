# tests.py

import unittest

from database import initialize_database, transaction
from models import add_student, update_email, delete_student
from database import get_connection


class DatabaseTests(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        initialize_database()

    def test_student_crud(self):
        email = "test_student@example.com"
        updated_email = "updated_test@example.com"

        with transaction() as conn:
            conn.execute(
                "DELETE FROM students WHERE email IN (?, ?)",
                (email, updated_email),
            )

        add_student("Test Student", email, "TEST", 2025)

        conn = get_connection()
        try:
            row = conn.execute(
                "SELECT * FROM students WHERE email = ?",
                (email,),
            ).fetchone()

            self.assertIsNotNone(row)
        finally:
            conn.close()

        update_email(row["student_id"], updated_email)

        conn = get_connection()
        try:
            updated = conn.execute(
                "SELECT email FROM students WHERE student_id = ?",
                (row["student_id"],),
            ).fetchone()

            self.assertEqual(updated["email"], updated_email)
        finally:
            conn.close()

        delete_student(row["student_id"])

    def test_invalid_marks_rejected_by_database(self):
        with transaction() as conn:
            with self.assertRaises(Exception):
                conn.execute("""
                    INSERT INTO scores(enrollment_id, marks)
                    VALUES (-999, 150)
                """)

    def test_duplicate_email_rejected(self):
        email = "duplicate_test@example.com"

        with transaction() as conn:
            conn.execute(
                "DELETE FROM students WHERE email = ?", (email,)
            )

        add_student("Duplicate Test", email, "TEST", 2025)

        try:
            with self.assertRaises(Exception):
                add_student("Another Student", email, "TEST", 2025)
        finally:
            with transaction() as conn:
                conn.execute(
                    "DELETE FROM students WHERE email = ?", (email,)
                )


if __name__ == "__main__":
    unittest.main(verbosity=2)