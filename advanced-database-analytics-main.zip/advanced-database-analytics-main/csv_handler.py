# csv_handler.py

import csv
from pathlib import Path

from database import transaction, get_connection
from audit import log_action


EXPORT_DIR = Path(__file__).resolve().parent / "exports"
EXPORT_DIR.mkdir(exist_ok=True)


def import_students(file_path):
    imported = 0

    with open(file_path, newline="", encoding="utf-8-sig") as file:
        reader = csv.DictReader(file)

        required = {
            "name", "email", "department", "admission_year"
        }

        if not reader.fieldnames or not required.issubset(reader.fieldnames):
            raise ValueError(
                "CSV columns required: "
                "name,email,department,admission_year"
            )

        with transaction() as conn:
            for row in reader:
                name = row["name"].strip()
                email = row["email"].strip().lower()
                department = row["department"].strip()
                year = int(row["admission_year"])

                if not name or not department or "@" not in email:
                    raise ValueError("Invalid student record.")

                conn.execute("""
                    INSERT INTO students
                        (name, email, department, admission_year)
                    VALUES (?, ?, ?, ?)
                """, (name, email, department, year))

                imported += 1

            log_action(
                conn, "CSV_IMPORT", "students",
                f"Imported {imported} records"
            )

    print(f"Imported {imported} students.")


def export_students():
    output = EXPORT_DIR / "students_export.csv"

    conn = get_connection()
    try:
        rows = conn.execute("""
            SELECT student_id, name, email, department, admission_year
            FROM students ORDER BY student_id
        """).fetchall()
    finally:
        conn.close()

    columns = [
        "student_id", "name", "email", "department", "admission_year"
    ]

    with output.open("w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=columns)
        writer.writeheader()
        writer.writerows([dict(row) for row in rows])

    print(f"Exported records to: {output}")