# audit.py

from database import transaction, get_connection


def log_action(conn, action, entity, details=""):
    conn.execute(
        """
        INSERT INTO audit_logs(action, entity, details)
        VALUES (?, ?, ?)
        """,
        (action, entity, details),
    )


def show_logs():
    conn = get_connection()
    try:
        rows = conn.execute("""
            SELECT * FROM audit_logs
            ORDER BY log_id DESC
            LIMIT 20
        """).fetchall()

        for row in rows:
            print(dict(row))
    finally:
        conn.close()