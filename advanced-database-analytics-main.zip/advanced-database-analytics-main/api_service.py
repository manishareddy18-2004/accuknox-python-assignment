# api_service.py

import json
import urllib.request
from database import transaction, get_connection
from audit import log_action


API_URL = "https://jsonplaceholder.typicode.com/users"


def fetch_contacts():
    request = urllib.request.Request(
        API_URL,
        headers={"User-Agent": "AcademicAnalytics/1.0"},
    )

    with urllib.request.urlopen(request, timeout=15) as response:
        if response.status != 200:
            raise RuntimeError(f"API error: HTTP {response.status}")

        data = json.loads(response.read().decode("utf-8"))

    if not isinstance(data, list):
        raise ValueError("Unexpected API response.")

    with transaction() as conn:
        for item in data:
            name = str(item.get("name", "")).strip()

            if not name:
                continue

            company = item.get("company") or {}

            conn.execute("""
                INSERT INTO external_contacts
                    (external_id, name, email, company)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(external_id)
                DO UPDATE SET
                    name = excluded.name,
                    email = excluded.email,
                    company = excluded.company
            """, (
                int(item["id"]),
                name,
                item.get("email"),
                company.get("name"),
            ))

        log_action(
            conn,
            "API_IMPORT",
            "external_contacts",
            f"Processed {len(data)} API records",
        )

    print(f"Processed {len(data)} external records.")


def list_contacts():
    conn = get_connection()
    try:
        rows = conn.execute("""
            SELECT * FROM external_contacts ORDER BY external_id
        """).fetchall()

        for row in rows:
            print(dict(row))
    finally:
        conn.close()