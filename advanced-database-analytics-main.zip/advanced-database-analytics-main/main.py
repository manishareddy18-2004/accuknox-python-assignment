# main.py

from database import initialize_database
from models import (
    add_student,
    list_students,
    add_course,
    enroll_student,
    record_score,
    update_email,
    delete_student,
    seed_demo_data,
)
from analytics import (
    department_report,
    top_students,
    above_average_students,
    course_report,
    student_transcript,
    inspect_query_plan,
)
from api_service import fetch_contacts, list_contacts
from csv_handler import import_students, export_students
from audit import show_logs


def main():
    initialize_database()

    actions = {
        "1": lambda: add_student(
            input("Name: "),
            input("Email: "),
            input("Department: "),
            int(input("Admission year: ")),
        ),
        "2": list_students,
        "3": lambda: add_course(
            input("Course code: "),
            input("Course name: "),
            int(input("Credits: ")),
        ),
        "4": lambda: enroll_student(
            int(input("Student ID: ")),
            int(input("Course ID: ")),
        ),
        "5": lambda: record_score(
            int(input("Enrollment ID: ")),
            float(input("Marks: ")),
            input("Exam type [Final]: ") or "Final",
        ),
        "6": lambda: student_transcript(
            int(input("Student ID: "))
        ),
        "7": lambda: update_email(
            int(input("Student ID: ")),
            input("New email: "),
        ),
        "8": lambda: delete_student(
            int(input("Student ID: "))
        ),
        "9": department_report,
        "10": lambda: top_students(
            int(input("Number of students [5]: ") or "5")
        ),
        "11": above_average_students,
        "12": course_report,
        "13": export_students,
        "14": lambda: import_students(input("CSV path: ").strip()),
        "15": fetch_contacts,
        "16": list_contacts,
        "17": show_logs,
        "18": inspect_query_plan,
        "19": seed_demo_data,
    }

    while True:
        print("""
=====================================
 ADVANCED DATABASE ANALYTICS SYSTEM
=====================================
1.  Add student
2.  List students
3.  Add course
4.  Enroll student
5.  Record/update marks
6.  View student transcript
7.  Update student email
8.  Delete student
9.  Department performance
10. Top students
11. Above-average students
12. Course performance
13. Export students to CSV
14. Import students from CSV
15. Fetch external API data
16. View external contacts
17. View audit logs
18. Inspect SQL query plan
19. Insert demonstration data
0.  Exit
=====================================
""")

        choice = input("Choose an option: ").strip()

        if choice == "0":
            print("Application closed.")
            break

        action = actions.get(choice)

        if action is None:
            print("Invalid option.")
            continue

        try:
            action()
        except (ValueError, TypeError) as exc:
            print(f"Invalid input: {exc}")
        except Exception as exc:
            print(f"Operation failed: {exc}")


if __name__ == "__main__":
    main()